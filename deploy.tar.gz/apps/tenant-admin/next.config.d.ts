export default nextConfig;
/** @type {import('next').NextConfig} */
declare const nextConfig: import("next").NextConfig;
//# sourceMappingURL=next.config.d.ts.map