export declare const getPayloadConfig: () => Promise<import("payload").SanitizedConfig>;
declare const _default: Promise<import("payload").SanitizedConfig>;
export default _default;
//# sourceMappingURL=payload.config.d.ts.map