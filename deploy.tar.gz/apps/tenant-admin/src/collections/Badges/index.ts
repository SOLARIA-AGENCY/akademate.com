/**
 * Badges Collection Exports
 */
export { Badges } from './Badges';
