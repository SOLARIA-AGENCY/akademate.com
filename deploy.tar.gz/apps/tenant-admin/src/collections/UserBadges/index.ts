/**
 * UserBadges Collection Exports
 */
export { UserBadges } from './UserBadges';
