/**
 * Campaigns Collection - Export
 *
 * Marketing campaign tracking with UTM parameters, budget management, and ROI analytics.
 */

export { Campaigns as default } from './Campaigns';
