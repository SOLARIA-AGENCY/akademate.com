import type { Access } from 'payload';
/**
 * Access Control: Read Media
 *
 * Who can view media files:
 * - Public: YES (public website needs to display images)
 * - Lectura: YES (read-only access to all content)
 * - Asesor: YES (need to view media for leads)
 * - Marketing: YES (need to view media for campaigns)
 * - Gestor: YES (full content management)
 * - Admin: YES (full system access)
 *
 * Business Logic:
 * - Media files are public assets (served on website)
 * - No sensitive PII stored in media metadata
 * - Public access enables CDN caching and performance
 */
export declare const canReadMedia: Access;
//# sourceMappingURL=canReadMedia.d.ts.map