import type { Access } from 'payload';
/**
 * Access Control: Update Media
 *
 * Who can update media metadata (alt text, caption, folder):
 * - Public: NO (unauthenticated users cannot modify)
 * - Lectura: NO (read-only role)
 * - Asesor: NO (can only upload, not modify)
 * - Marketing: YES, but ONLY own files (created_by = user.id)
 * - Gestor: YES (all files)
 * - Admin: YES (all files)
 *
 * Ownership-Based Permissions (Marketing):
 * - Marketing users can only update media they uploaded
 * - created_by field determines ownership
 * - Prevents unauthorized modification of other users' assets
 *
 * Security:
 * - Requires authentication
 * - Ownership verification prevents privilege escalation
 */
export declare const canUpdateMedia: Access;
//# sourceMappingURL=canUpdateMedia.d.ts.map