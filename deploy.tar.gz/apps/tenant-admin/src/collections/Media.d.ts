import type { CollectionConfig } from 'payload';
export declare const Media: CollectionConfig;
//# sourceMappingURL=Media.d.ts.map