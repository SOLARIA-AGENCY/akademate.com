import { OpsDashboard } from '../_components/OpsDashboard'

export const metadata = {
  title: 'Akademate Ops - Dashboard',
}

export default function OpsDashboardPage() {
  return <OpsDashboard />
}
