import { OpsDashboard } from './_components/OpsDashboard'

export const metadata = {
  title: 'Akademate Ops - Login',
}

export default function OpsRootPage() {
  return <OpsDashboard />
}
