--
-- PostgreSQL database cluster dump
--

\restrict BpuyvC71ZhqA3xm8wYLZUJlFYbInR4OeUpwcgvnngPJWx5ddk7oLjfXR7IPbSa3

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE akademate;
ALTER ROLE akademate WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:wMtpBAKDbCmaW62HzPnifw==$gX2ne6Hcbys2P4ksKzr6UDGAijRBiIaBAtc3/LmSjzo=:7MwJuVh0dFFc8BgYK6uYWgX0X7y6kGeXcpKYzJ/Uw/s=';

--
-- User Configurations
--








\unrestrict BpuyvC71ZhqA3xm8wYLZUJlFYbInR4OeUpwcgvnngPJWx5ddk7oLjfXR7IPbSa3

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict qecyZwMojyqdzcVpPIXBgi95q1zPMhrMuebH6YZPfAr8DQUlgm9q2cuTbXN9vGh

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict qecyZwMojyqdzcVpPIXBgi95q1zPMhrMuebH6YZPfAr8DQUlgm9q2cuTbXN9vGh

--
-- Database "akademate" dump
--

--
-- PostgreSQL database dump
--

\restrict zzydyBQdPI57yMYpoTODSsYzcWiMwgE9hefbc9phtTS5d6z2ifbdNEx9tMEQD7k

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: akademate; Type: DATABASE; Schema: -; Owner: akademate
--

CREATE DATABASE akademate WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE akademate OWNER TO akademate;

\unrestrict zzydyBQdPI57yMYpoTODSsYzcWiMwgE9hefbc9phtTS5d6z2ifbdNEx9tMEQD7k
\connect akademate
\restrict zzydyBQdPI57yMYpoTODSsYzcWiMwgE9hefbc9phtTS5d6z2ifbdNEx9tMEQD7k

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: akademate
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO akademate;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: akademate
--

COMMENT ON SCHEMA public IS '';


--
-- Name: enum_ads_templates_language; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_ads_templates_language AS ENUM (
    'es',
    'en',
    'ca'
);


ALTER TYPE public.enum_ads_templates_language OWNER TO akademate;

--
-- Name: enum_ads_templates_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_ads_templates_status AS ENUM (
    'draft',
    'active',
    'archived'
);


ALTER TYPE public.enum_ads_templates_status OWNER TO akademate;

--
-- Name: enum_ads_templates_template_type; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_ads_templates_template_type AS ENUM (
    'email',
    'social_post',
    'display_ad',
    'landing_page',
    'video_script',
    'other'
);


ALTER TYPE public.enum_ads_templates_template_type OWNER TO akademate;

--
-- Name: enum_ads_templates_tone; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_ads_templates_tone AS ENUM (
    'professional',
    'casual',
    'urgent',
    'friendly',
    'educational',
    'promotional'
);


ALTER TYPE public.enum_ads_templates_tone OWNER TO akademate;

--
-- Name: enum_audit_logs_action; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_audit_logs_action AS ENUM (
    'create',
    'read',
    'update',
    'delete',
    'export',
    'login',
    'logout',
    'permission_change'
);


ALTER TYPE public.enum_audit_logs_action OWNER TO akademate;

--
-- Name: enum_audit_logs_collection_name; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_audit_logs_collection_name AS ENUM (
    'users',
    'cycles',
    'campuses',
    'courses',
    'course-runs',
    'leads',
    'enrollments',
    'students',
    'campaigns',
    'ads-templates',
    'blog-posts',
    'faqs',
    'media',
    'audit-logs'
);


ALTER TYPE public.enum_audit_logs_collection_name OWNER TO akademate;

--
-- Name: enum_audit_logs_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_audit_logs_status AS ENUM (
    'success',
    'failure',
    'blocked'
);


ALTER TYPE public.enum_audit_logs_status OWNER TO akademate;

--
-- Name: enum_audit_logs_user_role; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_audit_logs_user_role AS ENUM (
    'admin',
    'gestor',
    'marketing',
    'asesor',
    'lectura'
);


ALTER TYPE public.enum_audit_logs_user_role OWNER TO akademate;

--
-- Name: enum_blog_posts_language; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_blog_posts_language AS ENUM (
    'es',
    'en',
    'ca'
);


ALTER TYPE public.enum_blog_posts_language OWNER TO akademate;

--
-- Name: enum_blog_posts_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_blog_posts_status AS ENUM (
    'draft',
    'published',
    'archived'
);


ALTER TYPE public.enum_blog_posts_status OWNER TO akademate;

--
-- Name: enum_campaigns_campaign_type; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_campaigns_campaign_type AS ENUM (
    'email',
    'social',
    'paid_ads',
    'organic',
    'event',
    'referral',
    'other'
);


ALTER TYPE public.enum_campaigns_campaign_type OWNER TO akademate;

--
-- Name: enum_campaigns_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_campaigns_status AS ENUM (
    'draft',
    'active',
    'paused',
    'completed',
    'archived'
);


ALTER TYPE public.enum_campaigns_status OWNER TO akademate;

--
-- Name: enum_course_runs_schedule_days; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_course_runs_schedule_days AS ENUM (
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday'
);


ALTER TYPE public.enum_course_runs_schedule_days OWNER TO akademate;

--
-- Name: enum_course_runs_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_course_runs_status AS ENUM (
    'draft',
    'published',
    'enrollment_open',
    'enrollment_closed',
    'in_progress',
    'completed',
    'cancelled'
);


ALTER TYPE public.enum_course_runs_status OWNER TO akademate;

--
-- Name: enum_courses_area; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_courses_area AS ENUM (
    'sanitaria',
    'horeca',
    'salud',
    'tecnologia',
    'audiovisual',
    'administracion',
    'marketing',
    'educacion'
);


ALTER TYPE public.enum_courses_area OWNER TO akademate;

--
-- Name: enum_courses_course_type; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_courses_course_type AS ENUM (
    'privado',
    'ocupados',
    'desempleados',
    'teleformacion',
    'ciclo_medio',
    'ciclo_superior'
);


ALTER TYPE public.enum_courses_course_type OWNER TO akademate;

--
-- Name: enum_courses_modality; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_courses_modality AS ENUM (
    'presencial',
    'online',
    'hibrido'
);


ALTER TYPE public.enum_courses_modality OWNER TO akademate;

--
-- Name: enum_cycles_level; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_cycles_level AS ENUM (
    'fp_basica',
    'grado_medio',
    'grado_superior',
    'certificado_profesionalidad'
);


ALTER TYPE public.enum_cycles_level OWNER TO akademate;

--
-- Name: enum_enrollments_financial_aid_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_enrollments_financial_aid_status AS ENUM (
    'none',
    'pending',
    'approved',
    'rejected'
);


ALTER TYPE public.enum_enrollments_financial_aid_status OWNER TO akademate;

--
-- Name: enum_enrollments_payment_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_enrollments_payment_status AS ENUM (
    'pending',
    'partial',
    'paid',
    'refunded',
    'waived'
);


ALTER TYPE public.enum_enrollments_payment_status OWNER TO akademate;

--
-- Name: enum_enrollments_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_enrollments_status AS ENUM (
    'pending',
    'confirmed',
    'waitlisted',
    'cancelled',
    'completed',
    'withdrawn'
);


ALTER TYPE public.enum_enrollments_status OWNER TO akademate;

--
-- Name: enum_entidades_financiadoras_tipo_subvencion; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_entidades_financiadoras_tipo_subvencion AS ENUM (
    'publica',
    'privada',
    'europea',
    'autonomica'
);


ALTER TYPE public.enum_entidades_financiadoras_tipo_subvencion OWNER TO akademate;

--
-- Name: enum_faqs_category; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_faqs_category AS ENUM (
    'courses',
    'enrollment',
    'payments',
    'technical',
    'general'
);


ALTER TYPE public.enum_faqs_category OWNER TO akademate;

--
-- Name: enum_faqs_language; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_faqs_language AS ENUM (
    'es',
    'en',
    'ca'
);


ALTER TYPE public.enum_faqs_language OWNER TO akademate;

--
-- Name: enum_faqs_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_faqs_status AS ENUM (
    'draft',
    'published',
    'archived'
);


ALTER TYPE public.enum_faqs_status OWNER TO akademate;

--
-- Name: enum_leads_preferred_contact_method; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_leads_preferred_contact_method AS ENUM (
    'email',
    'phone',
    'whatsapp'
);


ALTER TYPE public.enum_leads_preferred_contact_method OWNER TO akademate;

--
-- Name: enum_leads_preferred_contact_time; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_leads_preferred_contact_time AS ENUM (
    'morning',
    'afternoon',
    'evening',
    'anytime'
);


ALTER TYPE public.enum_leads_preferred_contact_time OWNER TO akademate;

--
-- Name: enum_leads_priority; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_leads_priority AS ENUM (
    'low',
    'medium',
    'high',
    'urgent'
);


ALTER TYPE public.enum_leads_priority OWNER TO akademate;

--
-- Name: enum_leads_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_leads_status AS ENUM (
    'new',
    'contacted',
    'qualified',
    'converted',
    'rejected',
    'spam'
);


ALTER TYPE public.enum_leads_status OWNER TO akademate;

--
-- Name: enum_staff_contract_type; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_staff_contract_type AS ENUM (
    'full_time',
    'part_time',
    'freelance'
);


ALTER TYPE public.enum_staff_contract_type OWNER TO akademate;

--
-- Name: enum_staff_employment_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_staff_employment_status AS ENUM (
    'active',
    'temporary_leave',
    'inactive'
);


ALTER TYPE public.enum_staff_employment_status OWNER TO akademate;

--
-- Name: enum_staff_specialties; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_staff_specialties AS ENUM (
    'marketing-digital',
    'desarrollo-web',
    'diseno-grafico',
    'audiovisual',
    'gestion-empresarial',
    'redes-sociales',
    'seo-sem',
    'ecommerce',
    'fotografia',
    'video'
);


ALTER TYPE public.enum_staff_specialties OWNER TO akademate;

--
-- Name: enum_staff_staff_type; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_staff_staff_type AS ENUM (
    'profesor',
    'administrativo'
);


ALTER TYPE public.enum_staff_staff_type OWNER TO akademate;

--
-- Name: enum_students_emergency_contact_relationship; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_students_emergency_contact_relationship AS ENUM (
    'parent',
    'father',
    'mother',
    'guardian',
    'spouse',
    'partner',
    'sibling',
    'friend',
    'other'
);


ALTER TYPE public.enum_students_emergency_contact_relationship OWNER TO akademate;

--
-- Name: enum_students_gender; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_students_gender AS ENUM (
    'male',
    'female',
    'non-binary',
    'prefer-not-to-say'
);


ALTER TYPE public.enum_students_gender OWNER TO akademate;

--
-- Name: enum_students_status; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_students_status AS ENUM (
    'active',
    'inactive',
    'suspended',
    'graduated'
);


ALTER TYPE public.enum_students_status OWNER TO akademate;

--
-- Name: enum_tenants_settings_language; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_tenants_settings_language AS ENUM (
    'es',
    'en',
    'pt'
);


ALTER TYPE public.enum_tenants_settings_language OWNER TO akademate;

--
-- Name: enum_tenants_settings_timezone; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_tenants_settings_timezone AS ENUM (
    'Europe/Madrid',
    'Europe/London',
    'America/New_York',
    'America/Los_Angeles',
    'Atlantic/Canary'
);


ALTER TYPE public.enum_tenants_settings_timezone OWNER TO akademate;

--
-- Name: enum_users_role; Type: TYPE; Schema: public; Owner: akademate
--

CREATE TYPE public.enum_users_role AS ENUM (
    'superadmin',
    'admin',
    'gestor',
    'marketing',
    'asesor',
    'lectura'
);


ALTER TYPE public.enum_users_role OWNER TO akademate;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    account_id text NOT NULL,
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    access_token text,
    refresh_token text,
    id_token text,
    access_token_expires_at timestamp with time zone,
    refresh_token_expires_at timestamp with time zone,
    scope text,
    password text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO akademate;

--
-- Name: ads_templates; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.ads_templates (
    id integer NOT NULL,
    name character varying NOT NULL,
    description character varying,
    template_type public.enum_ads_templates_template_type NOT NULL,
    status public.enum_ads_templates_status DEFAULT 'draft'::public.enum_ads_templates_status NOT NULL,
    campaign_id integer,
    headline character varying NOT NULL,
    body_copy jsonb NOT NULL,
    call_to_action character varying,
    cta_url character varying,
    primary_image_url character varying,
    secondary_image_url character varying,
    video_url character varying,
    thumbnail_url character varying,
    target_audience character varying,
    tone public.enum_ads_templates_tone DEFAULT 'professional'::public.enum_ads_templates_tone NOT NULL,
    language public.enum_ads_templates_language DEFAULT 'es'::public.enum_ads_templates_language NOT NULL,
    version numeric DEFAULT 1,
    usage_count numeric DEFAULT 0,
    last_used_at timestamp(3) with time zone,
    active boolean DEFAULT true,
    archived_at timestamp(3) with time zone,
    created_by_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ads_templates OWNER TO akademate;

--
-- Name: ads_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.ads_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ads_templates_id_seq OWNER TO akademate;

--
-- Name: ads_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.ads_templates_id_seq OWNED BY public.ads_templates.id;


--
-- Name: ads_templates_texts; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.ads_templates_texts (
    id integer NOT NULL,
    "order" integer NOT NULL,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    text character varying
);


ALTER TABLE public.ads_templates_texts OWNER TO akademate;

--
-- Name: ads_templates_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.ads_templates_texts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ads_templates_texts_id_seq OWNER TO akademate;

--
-- Name: ads_templates_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.ads_templates_texts_id_seq OWNED BY public.ads_templates_texts.id;


--
-- Name: areas_formativas; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.areas_formativas (
    id integer NOT NULL,
    nombre character varying NOT NULL,
    codigo character varying NOT NULL,
    descripcion character varying,
    color character varying,
    activo boolean DEFAULT true,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.areas_formativas OWNER TO akademate;

--
-- Name: areas_formativas_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.areas_formativas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.areas_formativas_id_seq OWNER TO akademate;

--
-- Name: areas_formativas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.areas_formativas_id_seq OWNED BY public.areas_formativas.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    action public.enum_audit_logs_action NOT NULL,
    collection_name public.enum_audit_logs_collection_name NOT NULL,
    document_id character varying,
    user_id_id integer NOT NULL,
    user_email character varying NOT NULL,
    user_role public.enum_audit_logs_user_role NOT NULL,
    ip_address character varying NOT NULL,
    user_agent character varying,
    changes jsonb,
    metadata jsonb,
    status public.enum_audit_logs_status DEFAULT 'success'::public.enum_audit_logs_status NOT NULL,
    error_message character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO akademate;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO akademate;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.blog_posts (
    id integer NOT NULL,
    title character varying NOT NULL,
    slug character varying NOT NULL,
    excerpt character varying NOT NULL,
    content jsonb NOT NULL,
    featured_image character varying,
    og_image character varying,
    status public.enum_blog_posts_status DEFAULT 'draft'::public.enum_blog_posts_status NOT NULL,
    featured boolean DEFAULT false,
    published_at timestamp(3) with time zone,
    archived_at timestamp(3) with time zone,
    author_id integer NOT NULL,
    created_by_id integer,
    view_count numeric DEFAULT 0,
    estimated_read_time numeric,
    meta_title character varying,
    meta_description character varying,
    language public.enum_blog_posts_language DEFAULT 'es'::public.enum_blog_posts_language NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.blog_posts OWNER TO akademate;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.blog_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_posts_id_seq OWNER TO akademate;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.blog_posts_id_seq OWNED BY public.blog_posts.id;


--
-- Name: blog_posts_rels; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.blog_posts_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    courses_id integer
);


ALTER TABLE public.blog_posts_rels OWNER TO akademate;

--
-- Name: blog_posts_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.blog_posts_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_posts_rels_id_seq OWNER TO akademate;

--
-- Name: blog_posts_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.blog_posts_rels_id_seq OWNED BY public.blog_posts_rels.id;


--
-- Name: blog_posts_texts; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.blog_posts_texts (
    id integer NOT NULL,
    "order" integer NOT NULL,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    text character varying
);


ALTER TABLE public.blog_posts_texts OWNER TO akademate;

--
-- Name: blog_posts_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.blog_posts_texts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_posts_texts_id_seq OWNER TO akademate;

--
-- Name: blog_posts_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.blog_posts_texts_id_seq OWNED BY public.blog_posts_texts.id;


--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.campaigns (
    id integer NOT NULL,
    name character varying NOT NULL,
    description character varying,
    campaign_type public.enum_campaigns_campaign_type NOT NULL,
    status public.enum_campaigns_status DEFAULT 'draft'::public.enum_campaigns_status NOT NULL,
    course_id integer,
    utm_source character varying,
    utm_medium character varying,
    utm_campaign character varying,
    utm_term character varying,
    utm_content character varying,
    start_date timestamp(3) with time zone NOT NULL,
    end_date timestamp(3) with time zone,
    budget numeric,
    target_leads numeric,
    target_enrollments numeric,
    total_leads numeric,
    total_conversions numeric,
    conversion_rate numeric,
    cost_per_lead numeric,
    notes character varying,
    created_by_id integer,
    tenant_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.campaigns OWNER TO akademate;

--
-- Name: campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.campaigns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.campaigns_id_seq OWNER TO akademate;

--
-- Name: campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.campaigns_id_seq OWNED BY public.campaigns.id;


--
-- Name: campuses; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.campuses (
    id integer NOT NULL,
    slug character varying NOT NULL,
    name character varying NOT NULL,
    city character varying NOT NULL,
    address character varying,
    postal_code character varying,
    phone character varying,
    email character varying,
    maps_url character varying,
    tenant_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.campuses OWNER TO akademate;

--
-- Name: campuses_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.campuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.campuses_id_seq OWNER TO akademate;

--
-- Name: campuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.campuses_id_seq OWNED BY public.campuses.id;


--
-- Name: campuses_rels; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.campuses_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    staff_id integer
);


ALTER TABLE public.campuses_rels OWNER TO akademate;

--
-- Name: campuses_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.campuses_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.campuses_rels_id_seq OWNER TO akademate;

--
-- Name: campuses_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.campuses_rels_id_seq OWNED BY public.campuses_rels.id;


--
-- Name: classrooms; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.classrooms (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    capacity integer NOT NULL,
    floor integer,
    resources jsonb DEFAULT '[]'::jsonb,
    campus_id integer,
    is_active boolean DEFAULT true,
    notes character varying(500),
    tenant_id integer,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT classrooms_capacity_check CHECK (((capacity >= 1) AND (capacity <= 500)))
);


ALTER TABLE public.classrooms OWNER TO akademate;

--
-- Name: classrooms_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.classrooms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.classrooms_id_seq OWNER TO akademate;

--
-- Name: classrooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.classrooms_id_seq OWNED BY public.classrooms.id;


--
-- Name: course_runs; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.course_runs (
    id integer NOT NULL,
    course_id integer NOT NULL,
    campus_id integer,
    codigo character varying NOT NULL,
    start_date timestamp(3) with time zone NOT NULL,
    end_date timestamp(3) with time zone NOT NULL,
    enrollment_deadline timestamp(3) with time zone,
    schedule_time_start character varying,
    schedule_time_end character varying,
    max_students numeric DEFAULT 30 NOT NULL,
    min_students numeric DEFAULT 5 NOT NULL,
    current_enrollments numeric DEFAULT 0 NOT NULL,
    status public.enum_course_runs_status DEFAULT 'draft'::public.enum_course_runs_status NOT NULL,
    price_override numeric,
    financial_aid_available boolean DEFAULT false,
    instructor_id integer,
    notes character varying,
    completion_snapshot_final_student_count numeric,
    completion_snapshot_final_occupation_percentage numeric,
    completion_snapshot_final_price numeric,
    completion_snapshot_completed_at timestamp(3) with time zone,
    created_by_id integer,
    tenant_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    classroom_id integer,
    instructor_name character varying(200),
    modality character varying(50)
);


ALTER TABLE public.course_runs OWNER TO akademate;

--
-- Name: course_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.course_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.course_runs_id_seq OWNER TO akademate;

--
-- Name: course_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.course_runs_id_seq OWNED BY public.course_runs.id;


--
-- Name: course_runs_schedule_days; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.course_runs_schedule_days (
    "order" integer NOT NULL,
    parent_id integer NOT NULL,
    value public.enum_course_runs_schedule_days,
    id integer NOT NULL
);


ALTER TABLE public.course_runs_schedule_days OWNER TO akademate;

--
-- Name: course_runs_schedule_days_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.course_runs_schedule_days_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.course_runs_schedule_days_id_seq OWNER TO akademate;

--
-- Name: course_runs_schedule_days_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.course_runs_schedule_days_id_seq OWNED BY public.course_runs_schedule_days.id;


--
-- Name: courses; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    codigo character varying NOT NULL,
    slug character varying NOT NULL,
    name character varying NOT NULL,
    featured_image_id integer,
    cycle_id integer,
    short_description character varying,
    long_description jsonb,
    modality public.enum_courses_modality DEFAULT 'presencial'::public.enum_courses_modality NOT NULL,
    course_type public.enum_courses_course_type,
    area_formativa_id integer NOT NULL,
    area public.enum_courses_area,
    duration_hours numeric,
    base_price numeric,
    subsidy_percentage numeric DEFAULT 100,
    financial_aid_available boolean DEFAULT true,
    active boolean DEFAULT true,
    featured boolean DEFAULT false,
    meta_title character varying,
    meta_description character varying,
    created_by_id integer,
    tenant_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.courses OWNER TO akademate;

--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courses_id_seq OWNER TO akademate;

--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: courses_rels; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.courses_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    campuses_id integer
);


ALTER TABLE public.courses_rels OWNER TO akademate;

--
-- Name: courses_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.courses_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courses_rels_id_seq OWNER TO akademate;

--
-- Name: courses_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.courses_rels_id_seq OWNED BY public.courses_rels.id;


--
-- Name: cycles; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.cycles (
    id integer NOT NULL,
    slug character varying NOT NULL,
    name character varying NOT NULL,
    description character varying,
    level public.enum_cycles_level NOT NULL,
    order_display numeric DEFAULT 0,
    tenant_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cycles OWNER TO akademate;

--
-- Name: cycles_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.cycles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cycles_id_seq OWNER TO akademate;

--
-- Name: cycles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.cycles_id_seq OWNED BY public.cycles.id;


--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.enrollments (
    id integer NOT NULL,
    student_id integer NOT NULL,
    course_run_id integer NOT NULL,
    status public.enum_enrollments_status DEFAULT 'pending'::public.enum_enrollments_status NOT NULL,
    payment_status public.enum_enrollments_payment_status DEFAULT 'pending'::public.enum_enrollments_payment_status NOT NULL,
    total_amount numeric NOT NULL,
    amount_paid numeric DEFAULT 0 NOT NULL,
    financial_aid_applied boolean DEFAULT false,
    financial_aid_amount numeric DEFAULT 0,
    financial_aid_status public.enum_enrollments_financial_aid_status,
    enrolled_at timestamp(3) with time zone,
    confirmed_at timestamp(3) with time zone,
    completed_at timestamp(3) with time zone,
    cancelled_at timestamp(3) with time zone,
    attendance_percentage numeric,
    final_grade numeric,
    certificate_issued boolean DEFAULT false,
    certificate_url character varying,
    notes character varying,
    cancellation_reason character varying,
    created_by_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.enrollments OWNER TO akademate;

--
-- Name: enrollments_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.enrollments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.enrollments_id_seq OWNER TO akademate;

--
-- Name: enrollments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.enrollments_id_seq OWNED BY public.enrollments.id;


--
-- Name: entidades_financiadoras; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.entidades_financiadoras (
    id integer NOT NULL,
    nombre character varying NOT NULL,
    codigo character varying NOT NULL,
    descripcion character varying,
    logo_url character varying,
    tipo_subvencion public.enum_entidades_financiadoras_tipo_subvencion DEFAULT 'publica'::public.enum_entidades_financiadoras_tipo_subvencion NOT NULL,
    url_oficial character varying,
    activo boolean DEFAULT true,
    created_by_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.entidades_financiadoras OWNER TO akademate;

--
-- Name: entidades_financiadoras_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.entidades_financiadoras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.entidades_financiadoras_id_seq OWNER TO akademate;

--
-- Name: entidades_financiadoras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.entidades_financiadoras_id_seq OWNED BY public.entidades_financiadoras.id;


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.faqs (
    id integer NOT NULL,
    question character varying NOT NULL,
    slug character varying NOT NULL,
    answer jsonb NOT NULL,
    category public.enum_faqs_category NOT NULL,
    status public.enum_faqs_status DEFAULT 'draft'::public.enum_faqs_status NOT NULL,
    featured boolean DEFAULT false,
    published_at timestamp(3) with time zone,
    archived_at timestamp(3) with time zone,
    created_by_id integer,
    "order" numeric DEFAULT 0,
    related_course_id integer,
    view_count numeric DEFAULT 0,
    helpful_count numeric DEFAULT 0,
    language public.enum_faqs_language DEFAULT 'es'::public.enum_faqs_language NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.faqs OWNER TO akademate;

--
-- Name: faqs_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.faqs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.faqs_id_seq OWNER TO akademate;

--
-- Name: faqs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.faqs_id_seq OWNED BY public.faqs.id;


--
-- Name: faqs_texts; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.faqs_texts (
    id integer NOT NULL,
    "order" integer NOT NULL,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    text character varying
);


ALTER TABLE public.faqs_texts OWNER TO akademate;

--
-- Name: faqs_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.faqs_texts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.faqs_texts_id_seq OWNER TO akademate;

--
-- Name: faqs_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.faqs_texts_id_seq OWNED BY public.faqs_texts.id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.leads (
    id integer NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    email character varying NOT NULL,
    phone character varying NOT NULL,
    course_id integer,
    campus_id integer,
    campaign_id integer,
    message character varying,
    preferred_contact_method public.enum_leads_preferred_contact_method,
    preferred_contact_time public.enum_leads_preferred_contact_time DEFAULT 'anytime'::public.enum_leads_preferred_contact_time,
    gdpr_consent boolean DEFAULT false NOT NULL,
    privacy_policy_accepted boolean DEFAULT false NOT NULL,
    marketing_consent boolean DEFAULT false,
    consent_timestamp timestamp(3) with time zone,
    consent_ip_address character varying,
    status public.enum_leads_status DEFAULT 'new'::public.enum_leads_status NOT NULL,
    assigned_to_id integer,
    priority public.enum_leads_priority DEFAULT 'medium'::public.enum_leads_priority,
    utm_source character varying,
    utm_medium character varying,
    utm_campaign character varying,
    utm_term character varying,
    utm_content character varying,
    mailchimp_subscriber_id character varying,
    whatsapp_contact_id character varying,
    lead_score numeric DEFAULT 0,
    notes jsonb,
    last_contacted_at timestamp(3) with time zone,
    converted_at timestamp(3) with time zone,
    tenant_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.leads OWNER TO akademate;

--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.leads_id_seq OWNER TO akademate;

--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.media (
    id integer NOT NULL,
    alt character varying NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    url character varying,
    thumbnail_u_r_l character varying,
    filename character varying,
    mime_type character varying,
    filesize numeric,
    width numeric,
    height numeric,
    focal_x numeric,
    focal_y numeric,
    sizes_thumbnail_url character varying,
    sizes_thumbnail_width numeric,
    sizes_thumbnail_height numeric,
    sizes_thumbnail_mime_type character varying,
    sizes_thumbnail_filesize numeric,
    sizes_thumbnail_filename character varying,
    sizes_card_url character varying,
    sizes_card_width numeric,
    sizes_card_height numeric,
    sizes_card_mime_type character varying,
    sizes_card_filesize numeric,
    sizes_card_filename character varying,
    sizes_hero_url character varying,
    sizes_hero_width numeric,
    sizes_hero_height numeric,
    sizes_hero_mime_type character varying,
    sizes_hero_filesize numeric,
    sizes_hero_filename character varying
);


ALTER TABLE public.media OWNER TO akademate;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_id_seq OWNER TO akademate;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: payload_kv; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.payload_kv (
    id integer NOT NULL,
    key character varying NOT NULL,
    data jsonb NOT NULL
);


ALTER TABLE public.payload_kv OWNER TO akademate;

--
-- Name: payload_kv_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.payload_kv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_kv_id_seq OWNER TO akademate;

--
-- Name: payload_kv_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.payload_kv_id_seq OWNED BY public.payload_kv.id;


--
-- Name: payload_locked_documents; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.payload_locked_documents (
    id integer NOT NULL,
    global_slug character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_locked_documents OWNER TO akademate;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.payload_locked_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_id_seq OWNER TO akademate;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.payload_locked_documents_id_seq OWNED BY public.payload_locked_documents.id;


--
-- Name: payload_locked_documents_rels; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.payload_locked_documents_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    tenants_id integer,
    users_id integer,
    cycles_id integer,
    campuses_id integer,
    areas_formativas_id integer,
    entidades_financiadoras_id integer,
    courses_id integer,
    course_runs_id integer,
    students_id integer,
    enrollments_id integer,
    staff_id integer,
    campaigns_id integer,
    ads_templates_id integer,
    leads_id integer,
    blog_posts_id integer,
    faqs_id integer,
    media_id integer,
    audit_logs_id integer,
    modules_id integer,
    lessons_id integer,
    lesson_progress_id integer,
    materials_id integer,
    submissions_id integer,
    attendance_id integer,
    certificates_id integer,
    badges_id integer,
    user_badges_id integer,
    points_transactions_id integer,
    user_streaks_id integer
);


ALTER TABLE public.payload_locked_documents_rels OWNER TO akademate;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.payload_locked_documents_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNER TO akademate;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNED BY public.payload_locked_documents_rels.id;


--
-- Name: payload_migrations; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.payload_migrations (
    id integer NOT NULL,
    name character varying,
    batch numeric,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_migrations OWNER TO akademate;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.payload_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_migrations_id_seq OWNER TO akademate;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.payload_migrations_id_seq OWNED BY public.payload_migrations.id;


--
-- Name: payload_preferences; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.payload_preferences (
    id integer NOT NULL,
    key character varying,
    value jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_preferences OWNER TO akademate;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.payload_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_id_seq OWNER TO akademate;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.payload_preferences_id_seq OWNED BY public.payload_preferences.id;


--
-- Name: payload_preferences_rels; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.payload_preferences_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    users_id integer
);


ALTER TABLE public.payload_preferences_rels OWNER TO akademate;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.payload_preferences_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNER TO akademate;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNED BY public.payload_preferences_rels.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    token text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    ip_address text,
    user_agent text,
    user_id uuid NOT NULL
);


ALTER TABLE public.sessions OWNER TO akademate;

--
-- Name: staff; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.staff (
    id integer NOT NULL,
    staff_type public.enum_staff_staff_type DEFAULT 'profesor'::public.enum_staff_staff_type NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    full_name character varying,
    email character varying NOT NULL,
    phone character varying,
    bio character varying,
    photo_id integer,
    "position" character varying NOT NULL,
    contract_type public.enum_staff_contract_type DEFAULT 'full_time'::public.enum_staff_contract_type NOT NULL,
    employment_status public.enum_staff_employment_status DEFAULT 'active'::public.enum_staff_employment_status NOT NULL,
    hire_date timestamp(3) with time zone NOT NULL,
    is_active boolean DEFAULT true,
    notes character varying,
    created_by_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.staff OWNER TO akademate;

--
-- Name: staff_certifications; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.staff_certifications (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    title character varying,
    institution character varying,
    year numeric,
    document_id integer
);


ALTER TABLE public.staff_certifications OWNER TO akademate;

--
-- Name: staff_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_id_seq OWNER TO akademate;

--
-- Name: staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.staff_id_seq OWNED BY public.staff.id;


--
-- Name: staff_rels; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.staff_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    campuses_id integer
);


ALTER TABLE public.staff_rels OWNER TO akademate;

--
-- Name: staff_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.staff_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_rels_id_seq OWNER TO akademate;

--
-- Name: staff_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.staff_rels_id_seq OWNED BY public.staff_rels.id;


--
-- Name: staff_specialties; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.staff_specialties (
    "order" integer NOT NULL,
    parent_id integer NOT NULL,
    value public.enum_staff_specialties,
    id integer NOT NULL
);


ALTER TABLE public.staff_specialties OWNER TO akademate;

--
-- Name: staff_specialties_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.staff_specialties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_specialties_id_seq OWNER TO akademate;

--
-- Name: staff_specialties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.staff_specialties_id_seq OWNED BY public.staff_specialties.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.students (
    id integer NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    email character varying NOT NULL,
    phone character varying NOT NULL,
    dni character varying,
    address character varying,
    city character varying,
    postal_code character varying,
    country character varying DEFAULT 'España'::character varying,
    date_of_birth timestamp(3) with time zone,
    gender public.enum_students_gender,
    emergency_contact_name character varying,
    emergency_contact_phone character varying,
    emergency_contact_relationship public.enum_students_emergency_contact_relationship,
    gdpr_consent boolean DEFAULT false NOT NULL,
    privacy_policy_accepted boolean DEFAULT false NOT NULL,
    marketing_consent boolean DEFAULT false,
    consent_timestamp timestamp(3) with time zone,
    consent_ip_address character varying,
    status public.enum_students_status DEFAULT 'active'::public.enum_students_status NOT NULL,
    notes character varying,
    created_by_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.students OWNER TO akademate;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_id_seq OWNER TO akademate;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.tenants (
    id integer NOT NULL,
    name character varying NOT NULL,
    slug character varying NOT NULL,
    domain character varying,
    branding_logo_id integer,
    branding_favicon_id integer,
    branding_primary_color character varying DEFAULT '#F2014B'::character varying,
    branding_secondary_color character varying DEFAULT '#1a1a2e'::character varying,
    contact_email character varying,
    contact_phone character varying,
    contact_address character varying,
    contact_website character varying,
    settings_timezone public.enum_tenants_settings_timezone DEFAULT 'Europe/Madrid'::public.enum_tenants_settings_timezone,
    settings_language public.enum_tenants_settings_language DEFAULT 'es'::public.enum_tenants_settings_language,
    settings_features_enable_leads boolean DEFAULT true,
    settings_features_enable_campaigns boolean DEFAULT true,
    settings_features_enable_blog boolean DEFAULT true,
    settings_features_enable_analytics boolean DEFAULT true,
    integrations_ga4_measurement_id character varying,
    integrations_meta_pixel_id character varying,
    integrations_mailchimp_api_key character varying,
    integrations_whatsapp_business_id character varying,
    active boolean DEFAULT true,
    limits_max_users numeric DEFAULT 50,
    limits_max_courses numeric DEFAULT 100,
    limits_max_leads_per_month numeric DEFAULT 1000,
    limits_storage_quota_m_b numeric DEFAULT 5120,
    notes character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tenants OWNER TO akademate;

--
-- Name: tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.tenants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tenants_id_seq OWNER TO akademate;

--
-- Name: tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.tenants_id_seq OWNED BY public.tenants.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password character varying,
    name character varying NOT NULL,
    role public.enum_users_role DEFAULT 'lectura'::public.enum_users_role NOT NULL,
    tenant_id integer,
    avatar_url character varying,
    phone character varying,
    is_active boolean DEFAULT true,
    last_login_at timestamp(3) with time zone,
    login_count numeric DEFAULT 0,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    email character varying NOT NULL,
    reset_password_token character varying,
    reset_password_expiration timestamp(3) with time zone,
    salt character varying,
    hash character varying,
    login_attempts numeric DEFAULT 0,
    lock_until timestamp(3) with time zone,
    mfa_secret text,
    mfa_verified_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO akademate;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO akademate;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: users_rels; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.users_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    tenants_id integer
);


ALTER TABLE public.users_rels OWNER TO akademate;

--
-- Name: users_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.users_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_rels_id_seq OWNER TO akademate;

--
-- Name: users_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.users_rels_id_seq OWNED BY public.users_rels.id;


--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.users_roles (
    _order integer DEFAULT 0 NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    role character varying
);


ALTER TABLE public.users_roles OWNER TO akademate;

--
-- Name: users_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: akademate
--

CREATE SEQUENCE public.users_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_roles_id_seq OWNER TO akademate;

--
-- Name: users_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akademate
--

ALTER SEQUENCE public.users_roles_id_seq OWNED BY public.users_roles.id;


--
-- Name: users_sessions; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.users_sessions (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    created_at timestamp(3) with time zone,
    expires_at timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.users_sessions OWNER TO akademate;

--
-- Name: verifications; Type: TABLE; Schema: public; Owner: akademate
--

CREATE TABLE public.verifications (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.verifications OWNER TO akademate;

--
-- Name: ads_templates id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.ads_templates ALTER COLUMN id SET DEFAULT nextval('public.ads_templates_id_seq'::regclass);


--
-- Name: ads_templates_texts id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.ads_templates_texts ALTER COLUMN id SET DEFAULT nextval('public.ads_templates_texts_id_seq'::regclass);


--
-- Name: areas_formativas id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.areas_formativas ALTER COLUMN id SET DEFAULT nextval('public.areas_formativas_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: blog_posts id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_id_seq'::regclass);


--
-- Name: blog_posts_rels id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts_rels ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_rels_id_seq'::regclass);


--
-- Name: blog_posts_texts id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts_texts ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_texts_id_seq'::regclass);


--
-- Name: campaigns id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campaigns ALTER COLUMN id SET DEFAULT nextval('public.campaigns_id_seq'::regclass);


--
-- Name: campuses id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campuses ALTER COLUMN id SET DEFAULT nextval('public.campuses_id_seq'::regclass);


--
-- Name: campuses_rels id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campuses_rels ALTER COLUMN id SET DEFAULT nextval('public.campuses_rels_id_seq'::regclass);


--
-- Name: classrooms id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.classrooms ALTER COLUMN id SET DEFAULT nextval('public.classrooms_id_seq'::regclass);


--
-- Name: course_runs id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs ALTER COLUMN id SET DEFAULT nextval('public.course_runs_id_seq'::regclass);


--
-- Name: course_runs_schedule_days id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs_schedule_days ALTER COLUMN id SET DEFAULT nextval('public.course_runs_schedule_days_id_seq'::regclass);


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: courses_rels id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses_rels ALTER COLUMN id SET DEFAULT nextval('public.courses_rels_id_seq'::regclass);


--
-- Name: cycles id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.cycles ALTER COLUMN id SET DEFAULT nextval('public.cycles_id_seq'::regclass);


--
-- Name: enrollments id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.enrollments ALTER COLUMN id SET DEFAULT nextval('public.enrollments_id_seq'::regclass);


--
-- Name: entidades_financiadoras id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.entidades_financiadoras ALTER COLUMN id SET DEFAULT nextval('public.entidades_financiadoras_id_seq'::regclass);


--
-- Name: faqs id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.faqs ALTER COLUMN id SET DEFAULT nextval('public.faqs_id_seq'::regclass);


--
-- Name: faqs_texts id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.faqs_texts ALTER COLUMN id SET DEFAULT nextval('public.faqs_texts_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: payload_kv id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_kv ALTER COLUMN id SET DEFAULT nextval('public.payload_kv_id_seq'::regclass);


--
-- Name: payload_locked_documents id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_id_seq'::regclass);


--
-- Name: payload_locked_documents_rels id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_rels_id_seq'::regclass);


--
-- Name: payload_migrations id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_migrations ALTER COLUMN id SET DEFAULT nextval('public.payload_migrations_id_seq'::regclass);


--
-- Name: payload_preferences id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_preferences ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_id_seq'::regclass);


--
-- Name: payload_preferences_rels id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_preferences_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_rels_id_seq'::regclass);


--
-- Name: staff id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff ALTER COLUMN id SET DEFAULT nextval('public.staff_id_seq'::regclass);


--
-- Name: staff_rels id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_rels ALTER COLUMN id SET DEFAULT nextval('public.staff_rels_id_seq'::regclass);


--
-- Name: staff_specialties id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_specialties ALTER COLUMN id SET DEFAULT nextval('public.staff_specialties_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: tenants id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.tenants ALTER COLUMN id SET DEFAULT nextval('public.tenants_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: users_rels id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.users_rels ALTER COLUMN id SET DEFAULT nextval('public.users_rels_id_seq'::regclass);


--
-- Name: users_roles id; Type: DEFAULT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.users_roles ALTER COLUMN id SET DEFAULT nextval('public.users_roles_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.accounts (id, account_id, provider_id, user_id, access_token, refresh_token, id_token, access_token_expires_at, refresh_token_expires_at, scope, password, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ads_templates; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.ads_templates (id, name, description, template_type, status, campaign_id, headline, body_copy, call_to_action, cta_url, primary_image_url, secondary_image_url, video_url, thumbnail_url, target_audience, tone, language, version, usage_count, last_used_at, active, archived_at, created_by_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: ads_templates_texts; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.ads_templates_texts (id, "order", parent_id, path, text) FROM stdin;
\.


--
-- Data for Name: areas_formativas; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.areas_formativas (id, nombre, codigo, descripcion, color, activo, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.audit_logs (id, action, collection_name, document_id, user_id_id, user_email, user_role, ip_address, user_agent, changes, metadata, status, error_message, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.blog_posts (id, title, slug, excerpt, content, featured_image, og_image, status, featured, published_at, archived_at, author_id, created_by_id, view_count, estimated_read_time, meta_title, meta_description, language, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: blog_posts_rels; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.blog_posts_rels (id, "order", parent_id, path, courses_id) FROM stdin;
\.


--
-- Data for Name: blog_posts_texts; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.blog_posts_texts (id, "order", parent_id, path, text) FROM stdin;
\.


--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.campaigns (id, name, description, campaign_type, status, course_id, utm_source, utm_medium, utm_campaign, utm_term, utm_content, start_date, end_date, budget, target_leads, target_enrollments, total_leads, total_conversions, conversion_rate, cost_per_lead, notes, created_by_id, tenant_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: campuses; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.campuses (id, slug, name, city, address, postal_code, phone, email, maps_url, tenant_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: campuses_rels; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.campuses_rels (id, "order", parent_id, path, staff_id) FROM stdin;
\.


--
-- Data for Name: classrooms; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.classrooms (id, code, name, capacity, floor, resources, campus_id, is_active, notes, tenant_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: course_runs; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.course_runs (id, course_id, campus_id, codigo, start_date, end_date, enrollment_deadline, schedule_time_start, schedule_time_end, max_students, min_students, current_enrollments, status, price_override, financial_aid_available, instructor_id, notes, completion_snapshot_final_student_count, completion_snapshot_final_occupation_percentage, completion_snapshot_final_price, completion_snapshot_completed_at, created_by_id, tenant_id, updated_at, created_at, classroom_id, instructor_name, modality) FROM stdin;
\.


--
-- Data for Name: course_runs_schedule_days; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.course_runs_schedule_days ("order", parent_id, value, id) FROM stdin;
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.courses (id, codigo, slug, name, featured_image_id, cycle_id, short_description, long_description, modality, course_type, area_formativa_id, area, duration_hours, base_price, subsidy_percentage, financial_aid_available, active, featured, meta_title, meta_description, created_by_id, tenant_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: courses_rels; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.courses_rels (id, "order", parent_id, path, campuses_id) FROM stdin;
\.


--
-- Data for Name: cycles; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.cycles (id, slug, name, description, level, order_display, tenant_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.enrollments (id, student_id, course_run_id, status, payment_status, total_amount, amount_paid, financial_aid_applied, financial_aid_amount, financial_aid_status, enrolled_at, confirmed_at, completed_at, cancelled_at, attendance_percentage, final_grade, certificate_issued, certificate_url, notes, cancellation_reason, created_by_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: entidades_financiadoras; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.entidades_financiadoras (id, nombre, codigo, descripcion, logo_url, tipo_subvencion, url_oficial, activo, created_by_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.faqs (id, question, slug, answer, category, status, featured, published_at, archived_at, created_by_id, "order", related_course_id, view_count, helpful_count, language, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: faqs_texts; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.faqs_texts (id, "order", parent_id, path, text) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.leads (id, first_name, last_name, email, phone, course_id, campus_id, campaign_id, message, preferred_contact_method, preferred_contact_time, gdpr_consent, privacy_policy_accepted, marketing_consent, consent_timestamp, consent_ip_address, status, assigned_to_id, priority, utm_source, utm_medium, utm_campaign, utm_term, utm_content, mailchimp_subscriber_id, whatsapp_contact_id, lead_score, notes, last_contacted_at, converted_at, tenant_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.media (id, alt, updated_at, created_at, url, thumbnail_u_r_l, filename, mime_type, filesize, width, height, focal_x, focal_y, sizes_thumbnail_url, sizes_thumbnail_width, sizes_thumbnail_height, sizes_thumbnail_mime_type, sizes_thumbnail_filesize, sizes_thumbnail_filename, sizes_card_url, sizes_card_width, sizes_card_height, sizes_card_mime_type, sizes_card_filesize, sizes_card_filename, sizes_hero_url, sizes_hero_width, sizes_hero_height, sizes_hero_mime_type, sizes_hero_filesize, sizes_hero_filename) FROM stdin;
\.


--
-- Data for Name: payload_kv; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.payload_kv (id, key, data) FROM stdin;
\.


--
-- Data for Name: payload_locked_documents; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.payload_locked_documents (id, global_slug, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: payload_locked_documents_rels; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.payload_locked_documents_rels (id, "order", parent_id, path, tenants_id, users_id, cycles_id, campuses_id, areas_formativas_id, entidades_financiadoras_id, courses_id, course_runs_id, students_id, enrollments_id, staff_id, campaigns_id, ads_templates_id, leads_id, blog_posts_id, faqs_id, media_id, audit_logs_id, modules_id, lessons_id, lesson_progress_id, materials_id, submissions_id, attendance_id, certificates_id, badges_id, user_badges_id, points_transactions_id, user_streaks_id) FROM stdin;
\.


--
-- Data for Name: payload_migrations; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.payload_migrations (id, name, batch, updated_at, created_at) FROM stdin;
1	20251207_081627	1	2026-02-19 20:02:51.599+00	2026-02-19 20:02:51.595+00
\.


--
-- Data for Name: payload_preferences; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.payload_preferences (id, key, value, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: payload_preferences_rels; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.payload_preferences_rels (id, "order", parent_id, path, users_id) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.sessions (id, expires_at, token, created_at, updated_at, ip_address, user_agent, user_id) FROM stdin;
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.staff (id, staff_type, first_name, last_name, full_name, email, phone, bio, photo_id, "position", contract_type, employment_status, hire_date, is_active, notes, created_by_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: staff_certifications; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.staff_certifications (_order, _parent_id, id, title, institution, year, document_id) FROM stdin;
\.


--
-- Data for Name: staff_rels; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.staff_rels (id, "order", parent_id, path, campuses_id) FROM stdin;
\.


--
-- Data for Name: staff_specialties; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.staff_specialties ("order", parent_id, value, id) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.students (id, first_name, last_name, email, phone, dni, address, city, postal_code, country, date_of_birth, gender, emergency_contact_name, emergency_contact_phone, emergency_contact_relationship, gdpr_consent, privacy_policy_accepted, marketing_consent, consent_timestamp, consent_ip_address, status, notes, created_by_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.tenants (id, name, slug, domain, branding_logo_id, branding_favicon_id, branding_primary_color, branding_secondary_color, contact_email, contact_phone, contact_address, contact_website, settings_timezone, settings_language, settings_features_enable_leads, settings_features_enable_campaigns, settings_features_enable_blog, settings_features_enable_analytics, integrations_ga4_measurement_id, integrations_meta_pixel_id, integrations_mailchimp_api_key, integrations_whatsapp_business_id, active, limits_max_users, limits_max_courses, limits_max_leads_per_month, limits_storage_quota_m_b, notes, updated_at, created_at) FROM stdin;
1	CEP Formacion	cep-formacion	100.99.60.106	\N	\N	#F2014B	#0F172A	admin@cep.es	\N	\N	\N	Europe/Madrid	es	t	t	t	t	\N	\N	\N	\N	t	200	200	20000	10240	\N	2026-02-19 20:17:21.957+00	2026-02-19 20:17:21.957+00
2	Akademate	akademate-demo	100.99.60.106	\N	\N	#0066CC	#1a1a2e	demo@akademate.io	\N	\N	\N	Europe/Madrid	es	t	t	t	t	\N	\N	\N	\N	t	50	100	1000	5120	Tenant demo - nuevo cliente simulado. CEP data archivado bajo tenant 1.	2026-03-03 10:50:44.334+00	2026-03-03 10:50:44.334+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.users (id, password, name, role, tenant_id, avatar_url, phone, is_active, last_login_at, login_count, updated_at, created_at, email, reset_password_token, reset_password_expiration, salt, hash, login_attempts, lock_until, mfa_secret, mfa_verified_at) FROM stdin;
5	\N	CEP Tenant Admin	admin	\N	\N	\N	t	2026-03-04 10:16:29.51+00	94	2026-03-04 10:16:29.572+00	2026-02-20 13:47:01.973+00	admin@cep.es	\N	\N	36b3f502a439b984b1ee187d9ff3c8acc66fd503089e869ecd772f46ace97a52	7cd44bc05bcd51acda6171385c13be5436baa3a0b7cb63c4a89a667aa63185a05d28cf08a39295250d08a2569feb9c8ee3a2ebeaded6a413d1ff8eaebf81b4d0c151b13c481f6ec97154bb90f840d303012553e7b3ec249d94a02e8174f1031369858ce1310e023ce22352278601b195ab5a52eaf02af4ee00bc808cf1509afa26ae4e2b4cdbc50a51a7a2a5ecde0ba5a9e27a9341a4fcc858a539c2fbe686f9a0a9f98202af41e08778ccddfa73be4d348fc4dd6030c75760cd934c16309915bb160f985367f25db8b455738a066fe05f42375e30f6695f484140ab6770e167f64a7bec6744aee948e7a8fe4cb300a4e980a112c5a8f045cf6729602bf8b166fa354124a0faa259c3d75bb248e3a49d71ff2a832df45f1e5a56ca9b5444c7bb66754850bfe18f9084dba8fefd8a8cce9b23b996735bf6968fa4c80ba9346e774c45de29dffbb5d63f454744724f24158aa3490afaefb2e6d87960064b1ca94cb00e6cc8ac8d73dda53ba64fb631872738cccfa14f7440e56a580aafdecc96b386850f41e4a9e4de6b128d11777350247879bb9df6b8fe124f4c2f62f59479098c28fc7c74d581defc4858db6d9ef028bd2804eb6e965f99d11e06ece5081783722ce899de619fb9062deb15ac8416e634af6e3407b8529632d75ac9368b142b6decd579dbf12000cb50d3157c46c53854f12824001dec3c4ea09c526135476c	0	\N	\N	\N
4	\N	Akademate CMS Admin	superadmin	\N	\N	\N	t	\N	0	2026-03-03 10:16:04.296+00	2026-02-20 13:47:01.97+00	admin@akademate.com	\N	\N	36b3f502a439b984b1ee187d9ff3c8acc66fd503089e869ecd772f46ace97a52	7cd44bc05bcd51acda6171385c13be5436baa3a0b7cb63c4a89a667aa63185a05d28cf08a39295250d08a2569feb9c8ee3a2ebeaded6a413d1ff8eaebf81b4d0c151b13c481f6ec97154bb90f840d303012553e7b3ec249d94a02e8174f1031369858ce1310e023ce22352278601b195ab5a52eaf02af4ee00bc808cf1509afa26ae4e2b4cdbc50a51a7a2a5ecde0ba5a9e27a9341a4fcc858a539c2fbe686f9a0a9f98202af41e08778ccddfa73be4d348fc4dd6030c75760cd934c16309915bb160f985367f25db8b455738a066fe05f42375e30f6695f484140ab6770e167f64a7bec6744aee948e7a8fe4cb300a4e980a112c5a8f045cf6729602bf8b166fa354124a0faa259c3d75bb248e3a49d71ff2a832df45f1e5a56ca9b5444c7bb66754850bfe18f9084dba8fefd8a8cce9b23b996735bf6968fa4c80ba9346e774c45de29dffbb5d63f454744724f24158aa3490afaefb2e6d87960064b1ca94cb00e6cc8ac8d73dda53ba64fb631872738cccfa14f7440e56a580aafdecc96b386850f41e4a9e4de6b128d11777350247879bb9df6b8fe124f4c2f62f59479098c28fc7c74d581defc4858db6d9ef028bd2804eb6e965f99d11e06ece5081783722ce899de619fb9062deb15ac8416e634af6e3407b8529632d75ac9368b142b6decd579dbf12000cb50d3157c46c53854f12824001dec3c4ea09c526135476c	3	\N	\N	\N
3	\N	Ops Superadmin	superadmin	\N	\N	\N	t	\N	0	2026-02-20 13:47:01.959+00	2026-02-20 13:47:01.959+00	ops@akademate.com	\N	\N	36b3f502a439b984b1ee187d9ff3c8acc66fd503089e869ecd772f46ace97a52	7cd44bc05bcd51acda6171385c13be5436baa3a0b7cb63c4a89a667aa63185a05d28cf08a39295250d08a2569feb9c8ee3a2ebeaded6a413d1ff8eaebf81b4d0c151b13c481f6ec97154bb90f840d303012553e7b3ec249d94a02e8174f1031369858ce1310e023ce22352278601b195ab5a52eaf02af4ee00bc808cf1509afa26ae4e2b4cdbc50a51a7a2a5ecde0ba5a9e27a9341a4fcc858a539c2fbe686f9a0a9f98202af41e08778ccddfa73be4d348fc4dd6030c75760cd934c16309915bb160f985367f25db8b455738a066fe05f42375e30f6695f484140ab6770e167f64a7bec6744aee948e7a8fe4cb300a4e980a112c5a8f045cf6729602bf8b166fa354124a0faa259c3d75bb248e3a49d71ff2a832df45f1e5a56ca9b5444c7bb66754850bfe18f9084dba8fefd8a8cce9b23b996735bf6968fa4c80ba9346e774c45de29dffbb5d63f454744724f24158aa3490afaefb2e6d87960064b1ca94cb00e6cc8ac8d73dda53ba64fb631872738cccfa14f7440e56a580aafdecc96b386850f41e4a9e4de6b128d11777350247879bb9df6b8fe124f4c2f62f59479098c28fc7c74d581defc4858db6d9ef028bd2804eb6e965f99d11e06ece5081783722ce899de619fb9062deb15ac8416e634af6e3407b8529632d75ac9368b142b6decd579dbf12000cb50d3157c46c53854f12824001dec3c4ea09c526135476c	0	\N	\N	\N
2	\N	Super Admin	superadmin	\N	\N	\N	t	2026-02-20 13:39:23.351+00	71	2026-03-05 11:59:24.389+00	2026-02-19 20:03:41.163+00	superadmin@cepcomunicacion.com	\N	\N	36b3f502a439b984b1ee187d9ff3c8acc66fd503089e869ecd772f46ace97a52	7cd44bc05bcd51acda6171385c13be5436baa3a0b7cb63c4a89a667aa63185a05d28cf08a39295250d08a2569feb9c8ee3a2ebeaded6a413d1ff8eaebf81b4d0c151b13c481f6ec97154bb90f840d303012553e7b3ec249d94a02e8174f1031369858ce1310e023ce22352278601b195ab5a52eaf02af4ee00bc808cf1509afa26ae4e2b4cdbc50a51a7a2a5ecde0ba5a9e27a9341a4fcc858a539c2fbe686f9a0a9f98202af41e08778ccddfa73be4d348fc4dd6030c75760cd934c16309915bb160f985367f25db8b455738a066fe05f42375e30f6695f484140ab6770e167f64a7bec6744aee948e7a8fe4cb300a4e980a112c5a8f045cf6729602bf8b166fa354124a0faa259c3d75bb248e3a49d71ff2a832df45f1e5a56ca9b5444c7bb66754850bfe18f9084dba8fefd8a8cce9b23b996735bf6968fa4c80ba9346e774c45de29dffbb5d63f454744724f24158aa3490afaefb2e6d87960064b1ca94cb00e6cc8ac8d73dda53ba64fb631872738cccfa14f7440e56a580aafdecc96b386850f41e4a9e4de6b128d11777350247879bb9df6b8fe124f4c2f62f59479098c28fc7c74d581defc4858db6d9ef028bd2804eb6e965f99d11e06ece5081783722ce899de619fb9062deb15ac8416e634af6e3407b8529632d75ac9368b142b6decd579dbf12000cb50d3157c46c53854f12824001dec3c4ea09c526135476c	3	\N	\N	\N
\.


--
-- Data for Name: users_rels; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.users_rels (id, "order", parent_id, path, tenants_id) FROM stdin;
\.


--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.users_roles (_order, _parent_id, id, role) FROM stdin;
1	2	4	superadmin
1	5	3	admin
1	4	2	superadmin
1	3	1	superadmin
\.


--
-- Data for Name: users_sessions; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.users_sessions (_order, _parent_id, id, created_at, expires_at) FROM stdin;
1	2	bea4aa60-d847-45b6-bed8-301f4a92ac82	2026-02-20 12:28:26.574+00	2026-02-20 14:28:26.574+00
2	2	4fe7829e-b624-4546-9d0f-bf3aba881fa2	2026-02-20 12:31:07.125+00	2026-02-20 14:31:07.125+00
3	2	7ee3c637-1e67-4baf-820b-3018b2347f9b	2026-02-20 12:31:33.812+00	2026-02-20 14:31:33.812+00
4	2	9f28042e-8350-4793-8ee4-94e6e637a399	2026-02-20 12:32:05.659+00	2026-02-20 14:32:05.659+00
5	2	68232085-f181-48a9-9a3e-a409056011e4	2026-02-20 12:32:15.709+00	2026-02-20 14:32:15.709+00
6	2	43951401-5290-4306-8e95-15b7e8a275f3	2026-02-20 12:33:01.865+00	2026-02-20 14:33:01.865+00
7	2	ff8f1949-b56f-417a-afbd-9fcd06a348f4	2026-02-20 12:34:08.841+00	2026-02-20 14:34:08.841+00
8	2	d0000587-54dc-4c6f-a7e3-aeff84f542bf	2026-02-20 12:34:18.843+00	2026-02-20 14:34:18.843+00
9	2	3a6b1541-5e3c-46d0-a294-f9836f54bef8	2026-02-20 12:42:01.101+00	2026-02-20 14:42:01.101+00
10	2	d2ba987a-01da-4f6a-9101-ae748d43cca1	2026-02-20 12:43:01.835+00	2026-02-20 14:43:01.835+00
11	2	256991a3-757a-41b2-bee9-43c379dbc403	2026-02-20 12:47:35.419+00	2026-02-20 14:47:35.419+00
12	2	eb4e3fb8-1049-48d5-9d7d-7aa4030a8219	2026-02-20 12:47:37.599+00	2026-02-20 14:47:37.599+00
13	2	6292cc9f-bed4-41eb-9f3f-9489bafefeb6	2026-02-20 12:50:16.367+00	2026-02-20 14:50:16.367+00
14	2	2f6f432e-6ede-4dd7-a3ac-e9bec0fc5701	2026-02-20 12:52:29.749+00	2026-02-20 14:52:29.749+00
15	2	d81ce8c0-af6d-45a2-8886-6318ae6e71b2	2026-02-20 13:18:49.785+00	2026-02-20 15:18:49.785+00
16	2	ceba00d9-659d-40c6-b714-83566213c47a	2026-02-20 13:39:22.006+00	2026-02-20 15:39:22.006+00
1	4	19a6a431-e3f5-4b81-9004-2015a2136317	2026-02-20 13:47:04.011+00	2026-02-20 15:47:04.011+00
2	4	1126b813-5a8c-49f9-a7a6-f0dec63b221f	2026-02-20 13:54:05.935+00	2026-02-20 15:54:05.935+00
1	3	f8538ca2-604f-4258-8c95-8bf136f4dad0	2026-02-20 13:47:02.871+00	2026-02-20 15:47:02.871+00
2	3	8c2cf72f-caf3-47e4-ba2f-c214adbac3aa	2026-02-20 13:53:18.827+00	2026-02-20 15:53:18.827+00
3	3	691a2462-84a4-471d-a073-e00c38219aa8	2026-02-20 13:54:05.532+00	2026-02-20 15:54:05.532+00
4	3	da44d95c-811e-4711-91d3-10f0a03f7660	2026-02-20 15:07:59.264+00	2026-02-20 17:07:59.264+00
1	5	802297f6-6870-4915-bb1c-442301308e9e	2026-03-05 11:59:24.797+00	2026-03-05 13:59:24.797+00
\.


--
-- Data for Name: verifications; Type: TABLE DATA; Schema: public; Owner: akademate
--

COPY public.verifications (id, identifier, value, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: ads_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.ads_templates_id_seq', 1, false);


--
-- Name: ads_templates_texts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.ads_templates_texts_id_seq', 1, false);


--
-- Name: areas_formativas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.areas_formativas_id_seq', 3, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.blog_posts_id_seq', 1, false);


--
-- Name: blog_posts_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.blog_posts_rels_id_seq', 1, false);


--
-- Name: blog_posts_texts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.blog_posts_texts_id_seq', 1, false);


--
-- Name: campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.campaigns_id_seq', 1, false);


--
-- Name: campuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.campuses_id_seq', 2, true);


--
-- Name: campuses_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.campuses_rels_id_seq', 1, false);


--
-- Name: classrooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.classrooms_id_seq', 1, false);


--
-- Name: course_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.course_runs_id_seq', 3, true);


--
-- Name: course_runs_schedule_days_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.course_runs_schedule_days_id_seq', 1, false);


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.courses_id_seq', 3, true);


--
-- Name: courses_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.courses_rels_id_seq', 1, false);


--
-- Name: cycles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.cycles_id_seq', 1, false);


--
-- Name: enrollments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.enrollments_id_seq', 3, true);


--
-- Name: entidades_financiadoras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.entidades_financiadoras_id_seq', 1, false);


--
-- Name: faqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.faqs_id_seq', 1, false);


--
-- Name: faqs_texts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.faqs_texts_id_seq', 1, false);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.leads_id_seq', 4, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.media_id_seq', 1, false);


--
-- Name: payload_kv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.payload_kv_id_seq', 1, false);


--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.payload_locked_documents_id_seq', 1, false);


--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.payload_locked_documents_rels_id_seq', 1, false);


--
-- Name: payload_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.payload_migrations_id_seq', 1, true);


--
-- Name: payload_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.payload_preferences_id_seq', 1, false);


--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.payload_preferences_rels_id_seq', 1, false);


--
-- Name: staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.staff_id_seq', 3, true);


--
-- Name: staff_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.staff_rels_id_seq', 1, false);


--
-- Name: staff_specialties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.staff_specialties_id_seq', 1, false);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.students_id_seq', 3, true);


--
-- Name: tenants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.tenants_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: users_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.users_rels_id_seq', 1, false);


--
-- Name: users_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akademate
--

SELECT pg_catalog.setval('public.users_roles_id_seq', 4, true);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: ads_templates ads_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.ads_templates
    ADD CONSTRAINT ads_templates_pkey PRIMARY KEY (id);


--
-- Name: ads_templates_texts ads_templates_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.ads_templates_texts
    ADD CONSTRAINT ads_templates_texts_pkey PRIMARY KEY (id);


--
-- Name: areas_formativas areas_formativas_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.areas_formativas
    ADD CONSTRAINT areas_formativas_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: blog_posts_rels blog_posts_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts_rels
    ADD CONSTRAINT blog_posts_rels_pkey PRIMARY KEY (id);


--
-- Name: blog_posts_texts blog_posts_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts_texts
    ADD CONSTRAINT blog_posts_texts_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: campuses campuses_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campuses
    ADD CONSTRAINT campuses_pkey PRIMARY KEY (id);


--
-- Name: campuses_rels campuses_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campuses_rels
    ADD CONSTRAINT campuses_rels_pkey PRIMARY KEY (id);


--
-- Name: classrooms classrooms_code_key; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_code_key UNIQUE (code);


--
-- Name: classrooms classrooms_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_pkey PRIMARY KEY (id);


--
-- Name: course_runs course_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs
    ADD CONSTRAINT course_runs_pkey PRIMARY KEY (id);


--
-- Name: course_runs_schedule_days course_runs_schedule_days_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs_schedule_days
    ADD CONSTRAINT course_runs_schedule_days_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: courses_rels courses_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses_rels
    ADD CONSTRAINT courses_rels_pkey PRIMARY KEY (id);


--
-- Name: cycles cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.cycles
    ADD CONSTRAINT cycles_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: entidades_financiadoras entidades_financiadoras_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.entidades_financiadoras
    ADD CONSTRAINT entidades_financiadoras_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: faqs_texts faqs_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.faqs_texts
    ADD CONSTRAINT faqs_texts_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: payload_kv payload_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_kv
    ADD CONSTRAINT payload_kv_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents payload_locked_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents
    ADD CONSTRAINT payload_locked_documents_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_pkey PRIMARY KEY (id);


--
-- Name: payload_migrations payload_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_migrations
    ADD CONSTRAINT payload_migrations_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences payload_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_preferences
    ADD CONSTRAINT payload_preferences_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences_rels payload_preferences_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_token_unique; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_token_unique UNIQUE (token);


--
-- Name: staff_certifications staff_certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_certifications
    ADD CONSTRAINT staff_certifications_pkey PRIMARY KEY (id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: staff_rels staff_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_rels
    ADD CONSTRAINT staff_rels_pkey PRIMARY KEY (id);


--
-- Name: staff_specialties staff_specialties_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_specialties
    ADD CONSTRAINT staff_specialties_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_rels users_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.users_rels
    ADD CONSTRAINT users_rels_pkey PRIMARY KEY (id);


--
-- Name: users_roles users_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.users_roles
    ADD CONSTRAINT users_roles_pkey PRIMARY KEY (id);


--
-- Name: users_sessions users_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.users_sessions
    ADD CONSTRAINT users_sessions_pkey PRIMARY KEY (id);


--
-- Name: verifications verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.verifications
    ADD CONSTRAINT verifications_pkey PRIMARY KEY (id);


--
-- Name: ads_templates_active_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX ads_templates_active_idx ON public.ads_templates USING btree (active);


--
-- Name: ads_templates_campaign_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX ads_templates_campaign_idx ON public.ads_templates USING btree (campaign_id);


--
-- Name: ads_templates_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX ads_templates_created_at_idx ON public.ads_templates USING btree (created_at);


--
-- Name: ads_templates_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX ads_templates_created_by_idx ON public.ads_templates USING btree (created_by_id);


--
-- Name: ads_templates_language_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX ads_templates_language_idx ON public.ads_templates USING btree (language);


--
-- Name: ads_templates_name_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX ads_templates_name_idx ON public.ads_templates USING btree (name);


--
-- Name: ads_templates_status_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX ads_templates_status_idx ON public.ads_templates USING btree (status);


--
-- Name: ads_templates_template_type_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX ads_templates_template_type_idx ON public.ads_templates USING btree (template_type);


--
-- Name: ads_templates_texts_order_parent; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX ads_templates_texts_order_parent ON public.ads_templates_texts USING btree ("order", parent_id);


--
-- Name: ads_templates_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX ads_templates_updated_at_idx ON public.ads_templates USING btree (updated_at);


--
-- Name: areas_formativas_codigo_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX areas_formativas_codigo_idx ON public.areas_formativas USING btree (codigo);


--
-- Name: areas_formativas_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX areas_formativas_created_at_idx ON public.areas_formativas USING btree (created_at);


--
-- Name: areas_formativas_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX areas_formativas_updated_at_idx ON public.areas_formativas USING btree (updated_at);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_collection_name_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX audit_logs_collection_name_idx ON public.audit_logs USING btree (collection_name);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_document_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX audit_logs_document_id_idx ON public.audit_logs USING btree (document_id);


--
-- Name: audit_logs_ip_address_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX audit_logs_ip_address_idx ON public.audit_logs USING btree (ip_address);


--
-- Name: audit_logs_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX audit_logs_updated_at_idx ON public.audit_logs USING btree (updated_at);


--
-- Name: audit_logs_user_email_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX audit_logs_user_email_idx ON public.audit_logs USING btree (user_email);


--
-- Name: audit_logs_user_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX audit_logs_user_id_idx ON public.audit_logs USING btree (user_id_id);


--
-- Name: blog_posts_author_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_author_idx ON public.blog_posts USING btree (author_id);


--
-- Name: blog_posts_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_created_at_idx ON public.blog_posts USING btree (created_at);


--
-- Name: blog_posts_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_created_by_idx ON public.blog_posts USING btree (created_by_id);


--
-- Name: blog_posts_featured_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_featured_idx ON public.blog_posts USING btree (featured);


--
-- Name: blog_posts_language_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_language_idx ON public.blog_posts USING btree (language);


--
-- Name: blog_posts_rels_courses_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_rels_courses_id_idx ON public.blog_posts_rels USING btree (courses_id);


--
-- Name: blog_posts_rels_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_rels_order_idx ON public.blog_posts_rels USING btree ("order");


--
-- Name: blog_posts_rels_parent_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_rels_parent_idx ON public.blog_posts_rels USING btree (parent_id);


--
-- Name: blog_posts_rels_path_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_rels_path_idx ON public.blog_posts_rels USING btree (path);


--
-- Name: blog_posts_slug_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX blog_posts_slug_idx ON public.blog_posts USING btree (slug);


--
-- Name: blog_posts_status_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_status_idx ON public.blog_posts USING btree (status);


--
-- Name: blog_posts_texts_order_parent; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_texts_order_parent ON public.blog_posts_texts USING btree ("order", parent_id);


--
-- Name: blog_posts_title_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_title_idx ON public.blog_posts USING btree (title);


--
-- Name: blog_posts_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX blog_posts_updated_at_idx ON public.blog_posts USING btree (updated_at);


--
-- Name: campaigns_campaign_type_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_campaign_type_idx ON public.campaigns USING btree (campaign_type);


--
-- Name: campaigns_course_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_course_idx ON public.campaigns USING btree (course_id);


--
-- Name: campaigns_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_created_at_idx ON public.campaigns USING btree (created_at);


--
-- Name: campaigns_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_created_by_idx ON public.campaigns USING btree (created_by_id);


--
-- Name: campaigns_name_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX campaigns_name_idx ON public.campaigns USING btree (name);


--
-- Name: campaigns_start_date_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_start_date_idx ON public.campaigns USING btree (start_date);


--
-- Name: campaigns_status_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_status_idx ON public.campaigns USING btree (status);


--
-- Name: campaigns_tenant_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_tenant_idx ON public.campaigns USING btree (tenant_id);


--
-- Name: campaigns_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_updated_at_idx ON public.campaigns USING btree (updated_at);


--
-- Name: campaigns_utm_campaign_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_utm_campaign_idx ON public.campaigns USING btree (utm_campaign);


--
-- Name: campaigns_utm_medium_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_utm_medium_idx ON public.campaigns USING btree (utm_medium);


--
-- Name: campaigns_utm_source_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campaigns_utm_source_idx ON public.campaigns USING btree (utm_source);


--
-- Name: campuses_city_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campuses_city_idx ON public.campuses USING btree (city);


--
-- Name: campuses_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campuses_created_at_idx ON public.campuses USING btree (created_at);


--
-- Name: campuses_rels_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campuses_rels_order_idx ON public.campuses_rels USING btree ("order");


--
-- Name: campuses_rels_parent_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campuses_rels_parent_idx ON public.campuses_rels USING btree (parent_id);


--
-- Name: campuses_rels_path_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campuses_rels_path_idx ON public.campuses_rels USING btree (path);


--
-- Name: campuses_rels_staff_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campuses_rels_staff_id_idx ON public.campuses_rels USING btree (staff_id);


--
-- Name: campuses_slug_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX campuses_slug_idx ON public.campuses USING btree (slug);


--
-- Name: campuses_tenant_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campuses_tenant_idx ON public.campuses USING btree (tenant_id);


--
-- Name: campuses_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX campuses_updated_at_idx ON public.campuses USING btree (updated_at);


--
-- Name: classrooms_campus_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX classrooms_campus_id_idx ON public.classrooms USING btree (campus_id);


--
-- Name: classrooms_is_active_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX classrooms_is_active_idx ON public.classrooms USING btree (is_active);


--
-- Name: classrooms_tenant_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX classrooms_tenant_id_idx ON public.classrooms USING btree (tenant_id);


--
-- Name: course_runs_campus_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_campus_idx ON public.course_runs USING btree (campus_id);


--
-- Name: course_runs_classroom_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_classroom_id_idx ON public.course_runs USING btree (classroom_id);


--
-- Name: course_runs_codigo_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX course_runs_codigo_idx ON public.course_runs USING btree (codigo);


--
-- Name: course_runs_course_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_course_idx ON public.course_runs USING btree (course_id);


--
-- Name: course_runs_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_created_at_idx ON public.course_runs USING btree (created_at);


--
-- Name: course_runs_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_created_by_idx ON public.course_runs USING btree (created_by_id);


--
-- Name: course_runs_instructor_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_instructor_idx ON public.course_runs USING btree (instructor_id);


--
-- Name: course_runs_schedule_days_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_schedule_days_order_idx ON public.course_runs_schedule_days USING btree ("order");


--
-- Name: course_runs_schedule_days_parent_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_schedule_days_parent_idx ON public.course_runs_schedule_days USING btree (parent_id);


--
-- Name: course_runs_start_date_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_start_date_idx ON public.course_runs USING btree (start_date);


--
-- Name: course_runs_status_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_status_idx ON public.course_runs USING btree (status);


--
-- Name: course_runs_tenant_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_tenant_idx ON public.course_runs USING btree (tenant_id);


--
-- Name: course_runs_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX course_runs_updated_at_idx ON public.course_runs USING btree (updated_at);


--
-- Name: courses_area_formativa_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_area_formativa_idx ON public.courses USING btree (area_formativa_id);


--
-- Name: courses_codigo_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX courses_codigo_idx ON public.courses USING btree (codigo);


--
-- Name: courses_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_created_at_idx ON public.courses USING btree (created_at);


--
-- Name: courses_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_created_by_idx ON public.courses USING btree (created_by_id);


--
-- Name: courses_cycle_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_cycle_idx ON public.courses USING btree (cycle_id);


--
-- Name: courses_featured_image_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_featured_image_idx ON public.courses USING btree (featured_image_id);


--
-- Name: courses_rels_campuses_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_rels_campuses_id_idx ON public.courses_rels USING btree (campuses_id);


--
-- Name: courses_rels_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_rels_order_idx ON public.courses_rels USING btree ("order");


--
-- Name: courses_rels_parent_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_rels_parent_idx ON public.courses_rels USING btree (parent_id);


--
-- Name: courses_rels_path_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_rels_path_idx ON public.courses_rels USING btree (path);


--
-- Name: courses_slug_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX courses_slug_idx ON public.courses USING btree (slug);


--
-- Name: courses_tenant_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_tenant_idx ON public.courses USING btree (tenant_id);


--
-- Name: courses_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX courses_updated_at_idx ON public.courses USING btree (updated_at);


--
-- Name: cycles_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX cycles_created_at_idx ON public.cycles USING btree (created_at);


--
-- Name: cycles_slug_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX cycles_slug_idx ON public.cycles USING btree (slug);


--
-- Name: cycles_tenant_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX cycles_tenant_idx ON public.cycles USING btree (tenant_id);


--
-- Name: cycles_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX cycles_updated_at_idx ON public.cycles USING btree (updated_at);


--
-- Name: enrollments_course_run_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX enrollments_course_run_idx ON public.enrollments USING btree (course_run_id);


--
-- Name: enrollments_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX enrollments_created_at_idx ON public.enrollments USING btree (created_at);


--
-- Name: enrollments_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX enrollments_created_by_idx ON public.enrollments USING btree (created_by_id);


--
-- Name: enrollments_payment_status_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX enrollments_payment_status_idx ON public.enrollments USING btree (payment_status);


--
-- Name: enrollments_status_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX enrollments_status_idx ON public.enrollments USING btree (status);


--
-- Name: enrollments_student_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX enrollments_student_idx ON public.enrollments USING btree (student_id);


--
-- Name: enrollments_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX enrollments_updated_at_idx ON public.enrollments USING btree (updated_at);


--
-- Name: entidades_financiadoras_codigo_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX entidades_financiadoras_codigo_idx ON public.entidades_financiadoras USING btree (codigo);


--
-- Name: entidades_financiadoras_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX entidades_financiadoras_created_at_idx ON public.entidades_financiadoras USING btree (created_at);


--
-- Name: entidades_financiadoras_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX entidades_financiadoras_created_by_idx ON public.entidades_financiadoras USING btree (created_by_id);


--
-- Name: entidades_financiadoras_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX entidades_financiadoras_updated_at_idx ON public.entidades_financiadoras USING btree (updated_at);


--
-- Name: faqs_category_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_category_idx ON public.faqs USING btree (category);


--
-- Name: faqs_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_created_at_idx ON public.faqs USING btree (created_at);


--
-- Name: faqs_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_created_by_idx ON public.faqs USING btree (created_by_id);


--
-- Name: faqs_featured_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_featured_idx ON public.faqs USING btree (featured);


--
-- Name: faqs_language_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_language_idx ON public.faqs USING btree (language);


--
-- Name: faqs_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_order_idx ON public.faqs USING btree ("order");


--
-- Name: faqs_question_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_question_idx ON public.faqs USING btree (question);


--
-- Name: faqs_related_course_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_related_course_idx ON public.faqs USING btree (related_course_id);


--
-- Name: faqs_slug_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX faqs_slug_idx ON public.faqs USING btree (slug);


--
-- Name: faqs_status_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_status_idx ON public.faqs USING btree (status);


--
-- Name: faqs_texts_order_parent; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_texts_order_parent ON public.faqs_texts USING btree ("order", parent_id);


--
-- Name: faqs_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX faqs_updated_at_idx ON public.faqs USING btree (updated_at);


--
-- Name: leads_assigned_to_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX leads_assigned_to_idx ON public.leads USING btree (assigned_to_id);


--
-- Name: leads_campaign_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX leads_campaign_idx ON public.leads USING btree (campaign_id);


--
-- Name: leads_campus_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX leads_campus_idx ON public.leads USING btree (campus_id);


--
-- Name: leads_course_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX leads_course_idx ON public.leads USING btree (course_id);


--
-- Name: leads_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX leads_created_at_idx ON public.leads USING btree (created_at);


--
-- Name: leads_email_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX leads_email_idx ON public.leads USING btree (email);


--
-- Name: leads_tenant_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX leads_tenant_idx ON public.leads USING btree (tenant_id);


--
-- Name: leads_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX leads_updated_at_idx ON public.leads USING btree (updated_at);


--
-- Name: media_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX media_created_at_idx ON public.media USING btree (created_at);


--
-- Name: media_filename_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX media_filename_idx ON public.media USING btree (filename);


--
-- Name: media_sizes_card_sizes_card_filename_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX media_sizes_card_sizes_card_filename_idx ON public.media USING btree (sizes_card_filename);


--
-- Name: media_sizes_hero_sizes_hero_filename_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX media_sizes_hero_sizes_hero_filename_idx ON public.media USING btree (sizes_hero_filename);


--
-- Name: media_sizes_thumbnail_sizes_thumbnail_filename_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX media_sizes_thumbnail_sizes_thumbnail_filename_idx ON public.media USING btree (sizes_thumbnail_filename);


--
-- Name: media_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX media_updated_at_idx ON public.media USING btree (updated_at);


--
-- Name: payload_kv_key_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX payload_kv_key_idx ON public.payload_kv USING btree (key);


--
-- Name: payload_locked_documents_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_created_at_idx ON public.payload_locked_documents USING btree (created_at);


--
-- Name: payload_locked_documents_global_slug_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_global_slug_idx ON public.payload_locked_documents USING btree (global_slug);


--
-- Name: payload_locked_documents_rels_ads_templates_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_ads_templates_id_idx ON public.payload_locked_documents_rels USING btree (ads_templates_id);


--
-- Name: payload_locked_documents_rels_areas_formativas_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_areas_formativas_id_idx ON public.payload_locked_documents_rels USING btree (areas_formativas_id);


--
-- Name: payload_locked_documents_rels_audit_logs_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_audit_logs_id_idx ON public.payload_locked_documents_rels USING btree (audit_logs_id);


--
-- Name: payload_locked_documents_rels_blog_posts_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_blog_posts_id_idx ON public.payload_locked_documents_rels USING btree (blog_posts_id);


--
-- Name: payload_locked_documents_rels_campaigns_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_campaigns_id_idx ON public.payload_locked_documents_rels USING btree (campaigns_id);


--
-- Name: payload_locked_documents_rels_campuses_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_campuses_id_idx ON public.payload_locked_documents_rels USING btree (campuses_id);


--
-- Name: payload_locked_documents_rels_course_runs_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_course_runs_id_idx ON public.payload_locked_documents_rels USING btree (course_runs_id);


--
-- Name: payload_locked_documents_rels_courses_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_courses_id_idx ON public.payload_locked_documents_rels USING btree (courses_id);


--
-- Name: payload_locked_documents_rels_cycles_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_cycles_id_idx ON public.payload_locked_documents_rels USING btree (cycles_id);


--
-- Name: payload_locked_documents_rels_enrollments_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_enrollments_id_idx ON public.payload_locked_documents_rels USING btree (enrollments_id);


--
-- Name: payload_locked_documents_rels_entidades_financiadoras_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_entidades_financiadoras_id_idx ON public.payload_locked_documents_rels USING btree (entidades_financiadoras_id);


--
-- Name: payload_locked_documents_rels_faqs_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_faqs_id_idx ON public.payload_locked_documents_rels USING btree (faqs_id);


--
-- Name: payload_locked_documents_rels_leads_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_leads_id_idx ON public.payload_locked_documents_rels USING btree (leads_id);


--
-- Name: payload_locked_documents_rels_media_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_media_id_idx ON public.payload_locked_documents_rels USING btree (media_id);


--
-- Name: payload_locked_documents_rels_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_order_idx ON public.payload_locked_documents_rels USING btree ("order");


--
-- Name: payload_locked_documents_rels_parent_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_parent_idx ON public.payload_locked_documents_rels USING btree (parent_id);


--
-- Name: payload_locked_documents_rels_path_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_path_idx ON public.payload_locked_documents_rels USING btree (path);


--
-- Name: payload_locked_documents_rels_staff_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_staff_id_idx ON public.payload_locked_documents_rels USING btree (staff_id);


--
-- Name: payload_locked_documents_rels_students_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_students_id_idx ON public.payload_locked_documents_rels USING btree (students_id);


--
-- Name: payload_locked_documents_rels_tenants_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_tenants_id_idx ON public.payload_locked_documents_rels USING btree (tenants_id);


--
-- Name: payload_locked_documents_rels_users_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_rels_users_id_idx ON public.payload_locked_documents_rels USING btree (users_id);


--
-- Name: payload_locked_documents_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_locked_documents_updated_at_idx ON public.payload_locked_documents USING btree (updated_at);


--
-- Name: payload_migrations_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_migrations_created_at_idx ON public.payload_migrations USING btree (created_at);


--
-- Name: payload_migrations_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_migrations_updated_at_idx ON public.payload_migrations USING btree (updated_at);


--
-- Name: payload_preferences_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_preferences_created_at_idx ON public.payload_preferences USING btree (created_at);


--
-- Name: payload_preferences_key_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_preferences_key_idx ON public.payload_preferences USING btree (key);


--
-- Name: payload_preferences_rels_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_preferences_rels_order_idx ON public.payload_preferences_rels USING btree ("order");


--
-- Name: payload_preferences_rels_parent_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_preferences_rels_parent_idx ON public.payload_preferences_rels USING btree (parent_id);


--
-- Name: payload_preferences_rels_path_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_preferences_rels_path_idx ON public.payload_preferences_rels USING btree (path);


--
-- Name: payload_preferences_rels_users_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_preferences_rels_users_id_idx ON public.payload_preferences_rels USING btree (users_id);


--
-- Name: payload_preferences_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX payload_preferences_updated_at_idx ON public.payload_preferences USING btree (updated_at);


--
-- Name: staff_certifications_document_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_certifications_document_idx ON public.staff_certifications USING btree (document_id);


--
-- Name: staff_certifications_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_certifications_order_idx ON public.staff_certifications USING btree (_order);


--
-- Name: staff_certifications_parent_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_certifications_parent_id_idx ON public.staff_certifications USING btree (_parent_id);


--
-- Name: staff_contract_type_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_contract_type_idx ON public.staff USING btree (contract_type);


--
-- Name: staff_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_created_at_idx ON public.staff USING btree (created_at);


--
-- Name: staff_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_created_by_idx ON public.staff USING btree (created_by_id);


--
-- Name: staff_email_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX staff_email_idx ON public.staff USING btree (email);


--
-- Name: staff_employment_status_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_employment_status_idx ON public.staff USING btree (employment_status);


--
-- Name: staff_full_name_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_full_name_idx ON public.staff USING btree (full_name);


--
-- Name: staff_hire_date_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_hire_date_idx ON public.staff USING btree (hire_date);


--
-- Name: staff_is_active_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_is_active_idx ON public.staff USING btree (is_active);


--
-- Name: staff_photo_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_photo_idx ON public.staff USING btree (photo_id);


--
-- Name: staff_rels_campuses_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_rels_campuses_id_idx ON public.staff_rels USING btree (campuses_id);


--
-- Name: staff_rels_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_rels_order_idx ON public.staff_rels USING btree ("order");


--
-- Name: staff_rels_parent_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_rels_parent_idx ON public.staff_rels USING btree (parent_id);


--
-- Name: staff_rels_path_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_rels_path_idx ON public.staff_rels USING btree (path);


--
-- Name: staff_specialties_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_specialties_order_idx ON public.staff_specialties USING btree ("order");


--
-- Name: staff_specialties_parent_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_specialties_parent_idx ON public.staff_specialties USING btree (parent_id);


--
-- Name: staff_staff_type_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_staff_type_idx ON public.staff USING btree (staff_type);


--
-- Name: staff_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX staff_updated_at_idx ON public.staff USING btree (updated_at);


--
-- Name: students_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX students_created_at_idx ON public.students USING btree (created_at);


--
-- Name: students_created_by_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX students_created_by_idx ON public.students USING btree (created_by_id);


--
-- Name: students_dni_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX students_dni_idx ON public.students USING btree (dni);


--
-- Name: students_email_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX students_email_idx ON public.students USING btree (email);


--
-- Name: students_status_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX students_status_idx ON public.students USING btree (status);


--
-- Name: students_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX students_updated_at_idx ON public.students USING btree (updated_at);


--
-- Name: tenants_branding_branding_favicon_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX tenants_branding_branding_favicon_idx ON public.tenants USING btree (branding_favicon_id);


--
-- Name: tenants_branding_branding_logo_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX tenants_branding_branding_logo_idx ON public.tenants USING btree (branding_logo_id);


--
-- Name: tenants_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX tenants_created_at_idx ON public.tenants USING btree (created_at);


--
-- Name: tenants_slug_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX tenants_slug_idx ON public.tenants USING btree (slug);


--
-- Name: tenants_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX tenants_updated_at_idx ON public.tenants USING btree (updated_at);


--
-- Name: users_created_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_created_at_idx ON public.users USING btree (created_at);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE UNIQUE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_rels_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_rels_order_idx ON public.users_rels USING btree ("order");


--
-- Name: users_rels_parent_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_rels_parent_id_idx ON public.users_rels USING btree (parent_id);


--
-- Name: users_rels_path_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_rels_path_idx ON public.users_rels USING btree (path);


--
-- Name: users_rels_tenants_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_rels_tenants_id_idx ON public.users_rels USING btree (tenants_id);


--
-- Name: users_roles_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_roles_order_idx ON public.users_roles USING btree (_order);


--
-- Name: users_roles_parent_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_roles_parent_id_idx ON public.users_roles USING btree (_parent_id);


--
-- Name: users_sessions_order_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_sessions_order_idx ON public.users_sessions USING btree (_order);


--
-- Name: users_sessions_parent_id_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_sessions_parent_id_idx ON public.users_sessions USING btree (_parent_id);


--
-- Name: users_tenant_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_tenant_idx ON public.users USING btree (tenant_id);


--
-- Name: users_updated_at_idx; Type: INDEX; Schema: public; Owner: akademate
--

CREATE INDEX users_updated_at_idx ON public.users USING btree (updated_at);


--
-- Name: ads_templates ads_templates_campaign_id_campaigns_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.ads_templates
    ADD CONSTRAINT ads_templates_campaign_id_campaigns_id_fk FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON DELETE SET NULL;


--
-- Name: ads_templates ads_templates_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.ads_templates
    ADD CONSTRAINT ads_templates_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ads_templates_texts ads_templates_texts_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.ads_templates_texts
    ADD CONSTRAINT ads_templates_texts_parent_fk FOREIGN KEY (parent_id) REFERENCES public.ads_templates(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_id_users_id_fk FOREIGN KEY (user_id_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: blog_posts blog_posts_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: blog_posts blog_posts_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: blog_posts_rels blog_posts_rels_courses_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts_rels
    ADD CONSTRAINT blog_posts_rels_courses_fk FOREIGN KEY (courses_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: blog_posts_rels blog_posts_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts_rels
    ADD CONSTRAINT blog_posts_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.blog_posts(id) ON DELETE CASCADE;


--
-- Name: blog_posts_texts blog_posts_texts_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.blog_posts_texts
    ADD CONSTRAINT blog_posts_texts_parent_fk FOREIGN KEY (parent_id) REFERENCES public.blog_posts(id) ON DELETE CASCADE;


--
-- Name: campaigns campaigns_course_id_courses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_course_id_courses_id_fk FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE SET NULL;


--
-- Name: campaigns campaigns_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: campaigns campaigns_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: campuses_rels campuses_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campuses_rels
    ADD CONSTRAINT campuses_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.campuses(id) ON DELETE CASCADE;


--
-- Name: campuses_rels campuses_rels_staff_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campuses_rels
    ADD CONSTRAINT campuses_rels_staff_fk FOREIGN KEY (staff_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: campuses campuses_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.campuses
    ADD CONSTRAINT campuses_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: classrooms classrooms_campus_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_campus_id_fkey FOREIGN KEY (campus_id) REFERENCES public.campuses(id) ON DELETE SET NULL;


--
-- Name: classrooms classrooms_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: course_runs course_runs_campus_id_campuses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs
    ADD CONSTRAINT course_runs_campus_id_campuses_id_fk FOREIGN KEY (campus_id) REFERENCES public.campuses(id) ON DELETE SET NULL;


--
-- Name: course_runs course_runs_classroom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs
    ADD CONSTRAINT course_runs_classroom_id_fkey FOREIGN KEY (classroom_id) REFERENCES public.classrooms(id) ON DELETE SET NULL;


--
-- Name: course_runs course_runs_course_id_courses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs
    ADD CONSTRAINT course_runs_course_id_courses_id_fk FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE SET NULL;


--
-- Name: course_runs course_runs_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs
    ADD CONSTRAINT course_runs_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: course_runs course_runs_instructor_id_staff_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs
    ADD CONSTRAINT course_runs_instructor_id_staff_id_fk FOREIGN KEY (instructor_id) REFERENCES public.staff(id) ON DELETE SET NULL;


--
-- Name: course_runs_schedule_days course_runs_schedule_days_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs_schedule_days
    ADD CONSTRAINT course_runs_schedule_days_parent_fk FOREIGN KEY (parent_id) REFERENCES public.course_runs(id) ON DELETE CASCADE;


--
-- Name: course_runs course_runs_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.course_runs
    ADD CONSTRAINT course_runs_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: courses courses_area_formativa_id_areas_formativas_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_area_formativa_id_areas_formativas_id_fk FOREIGN KEY (area_formativa_id) REFERENCES public.areas_formativas(id) ON DELETE SET NULL;


--
-- Name: courses courses_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: courses courses_cycle_id_cycles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_cycle_id_cycles_id_fk FOREIGN KEY (cycle_id) REFERENCES public.cycles(id) ON DELETE SET NULL;


--
-- Name: courses courses_featured_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_featured_image_id_media_id_fk FOREIGN KEY (featured_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: courses_rels courses_rels_campuses_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses_rels
    ADD CONSTRAINT courses_rels_campuses_fk FOREIGN KEY (campuses_id) REFERENCES public.campuses(id) ON DELETE CASCADE;


--
-- Name: courses_rels courses_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses_rels
    ADD CONSTRAINT courses_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: courses courses_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: cycles cycles_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.cycles
    ADD CONSTRAINT cycles_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: enrollments enrollments_course_run_id_course_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_course_run_id_course_runs_id_fk FOREIGN KEY (course_run_id) REFERENCES public.course_runs(id) ON DELETE SET NULL;


--
-- Name: enrollments enrollments_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: enrollments enrollments_student_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_student_id_leads_id_fk FOREIGN KEY (student_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: entidades_financiadoras entidades_financiadoras_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.entidades_financiadoras
    ADD CONSTRAINT entidades_financiadoras_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: faqs faqs_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: faqs faqs_related_course_id_courses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_related_course_id_courses_id_fk FOREIGN KEY (related_course_id) REFERENCES public.courses(id) ON DELETE SET NULL;


--
-- Name: faqs_texts faqs_texts_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.faqs_texts
    ADD CONSTRAINT faqs_texts_parent_fk FOREIGN KEY (parent_id) REFERENCES public.faqs(id) ON DELETE CASCADE;


--
-- Name: leads leads_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: leads leads_campaign_id_campaigns_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_campaign_id_campaigns_id_fk FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON DELETE SET NULL;


--
-- Name: leads leads_campus_id_campuses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_campus_id_campuses_id_fk FOREIGN KEY (campus_id) REFERENCES public.campuses(id) ON DELETE SET NULL;


--
-- Name: leads leads_course_id_courses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_course_id_courses_id_fk FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE SET NULL;


--
-- Name: leads leads_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_ads_templates_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_ads_templates_fk FOREIGN KEY (ads_templates_id) REFERENCES public.ads_templates(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_areas_formativas_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_areas_formativas_fk FOREIGN KEY (areas_formativas_id) REFERENCES public.areas_formativas(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_audit_logs_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_audit_logs_fk FOREIGN KEY (audit_logs_id) REFERENCES public.audit_logs(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_blog_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_blog_posts_fk FOREIGN KEY (blog_posts_id) REFERENCES public.blog_posts(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_campaigns_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_campaigns_fk FOREIGN KEY (campaigns_id) REFERENCES public.campaigns(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_campuses_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_campuses_fk FOREIGN KEY (campuses_id) REFERENCES public.campuses(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_course_runs_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_course_runs_fk FOREIGN KEY (course_runs_id) REFERENCES public.course_runs(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_courses_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_courses_fk FOREIGN KEY (courses_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_cycles_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_cycles_fk FOREIGN KEY (cycles_id) REFERENCES public.cycles(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_enrollments_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_enrollments_fk FOREIGN KEY (enrollments_id) REFERENCES public.enrollments(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_entidades_financiadoras_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_entidades_financiadoras_fk FOREIGN KEY (entidades_financiadoras_id) REFERENCES public.entidades_financiadoras(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_faqs_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_faqs_fk FOREIGN KEY (faqs_id) REFERENCES public.faqs(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_leads_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_leads_fk FOREIGN KEY (leads_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_media_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_media_fk FOREIGN KEY (media_id) REFERENCES public.media(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_locked_documents(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_staff_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_staff_fk FOREIGN KEY (staff_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_students_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_students_fk FOREIGN KEY (students_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_tenants_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_tenants_fk FOREIGN KEY (tenants_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_preferences(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: staff_certifications staff_certifications_document_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_certifications
    ADD CONSTRAINT staff_certifications_document_id_media_id_fk FOREIGN KEY (document_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: staff_certifications staff_certifications_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_certifications
    ADD CONSTRAINT staff_certifications_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: staff staff_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: staff staff_photo_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_photo_id_media_id_fk FOREIGN KEY (photo_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: staff_rels staff_rels_campuses_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_rels
    ADD CONSTRAINT staff_rels_campuses_fk FOREIGN KEY (campuses_id) REFERENCES public.campuses(id) ON DELETE CASCADE;


--
-- Name: staff_rels staff_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_rels
    ADD CONSTRAINT staff_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: staff_specialties staff_specialties_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.staff_specialties
    ADD CONSTRAINT staff_specialties_parent_fk FOREIGN KEY (parent_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: students students_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tenants tenants_branding_favicon_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_branding_favicon_id_media_id_fk FOREIGN KEY (branding_favicon_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: tenants tenants_branding_logo_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_branding_logo_id_media_id_fk FOREIGN KEY (branding_logo_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: users_sessions users_sessions_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.users_sessions
    ADD CONSTRAINT users_sessions_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: akademate
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: akademate
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict zzydyBQdPI57yMYpoTODSsYzcWiMwgE9hefbc9phtTS5d6z2ifbdNEx9tMEQD7k

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict oKki08RYNgN7MEINW30aLbZHFBBP0Go04BQgKXaLeVyNJI9HhmQh1ZQfMcUFQjp

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict oKki08RYNgN7MEINW30aLbZHFBBP0Go04BQgKXaLeVyNJI9HhmQh1ZQfMcUFQjp

--
-- PostgreSQL database cluster dump complete
--

